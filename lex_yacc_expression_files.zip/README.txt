Lex and Yacc arithmetic-expression validator

Files:
- lexer.l  : Flex/Lex scanner
- parser.y : Bison/Yacc grammar

Ubuntu setup:
  sudo apt update
  sudo apt install flex bison gcc

From this folder, run:
  bison -dy parser.y
  flex lexer.l
  gcc y.tab.c lex.yy.c -o expr -lfl
  ./expr

Type an expression and press Enter, e.g.:
  (5+3)*2

This program checks syntax only; it does not calculate the expression.
